U OVAJ FOLDER spusti screenshotove i nazovi ih TACNO ovako (mala slova):

  gui.png                 -> screenshot korisnickog interfejsa plugina (prozor konvertora)
  case14_bez_suma.png     -> plot case14 BEZ suma
  case14_sa_sumom.png     -> plot case14 SA sumom (sigma = 0.03)
  tabela_iteracija.png    -> tabela rjesenja iz dTwina (kolone e_i, f_i, eps)

Napomena:
- Ako neku sliku ne ubacis, izvjestaj ce se svejedno kompajlirati, ali ce na
  njenom mjestu pisati uokviren podsjetnik.
- Format moze biti .png ili .jpg, ali onda promijeni ekstenziju i u izvjestaj.tex
  (u \includegraphics / \slikaili pozivima).
- Slobodno dodaj i vise slika (npr. case3, case9) po istom principu.
